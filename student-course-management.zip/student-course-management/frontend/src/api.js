import axios from 'axios';

const API = axios.create({ baseURL: 'http://localhost:3000' });

export const addStudent = (data) => API.post('/students', data);
export const getStudents = () => API.get('/students');
export const getCourseStudents = (courseId) => API.get(`/courses/${courseId}/students`);
export const updateStudent = (id, data) => API.put(`/students/${id}`, data);
export const deleteStudent = (id) => API.delete(`/students/${id}`);
export const addCourse = (data) => API.post(`/courses`, data);
