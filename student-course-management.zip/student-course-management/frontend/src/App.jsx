import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import AddStudentForm from './components/AddStudentForm';
import StudentList from './components/StudentList';
import CourseStudents from './components/CoursesStudent';
import AddCourseForm from './components/AddCourseForm';

const App = () => {
  return (
    <Router>
      <div className="min-h-screen bg-gray-100">
        <nav className="bg-blue-600 text-white p-4 shadow-md">
          <div className="container mx-auto flex justify-between items-center">
            <ul className="flex space-x-4">
              <li>
                <Link to="/add-student" className="hover:underline">
                  Add Student
                </Link>
              </li>
              <li>
                <Link to="/students" className="hover:underline">
                  Student List
                </Link>
              </li>
              <li>
                <Link to="/course-students" className="hover:underline">
                  Course Students
                </Link>
              </li>
              <li>
                <Link to="/add-course" className="hover:underline">
                  Add Course
                </Link>
              </li>
            </ul>
          </div>
        </nav>

        <main className="container mx-auto p-4">
          <Routes>
            <Route path="/add-student" element={<AddStudentForm />} />
            <Route path="/students" element={<StudentList />} />
            <Route path="/course-students" element={<CourseStudents />} />
            <Route path="/add-course" element={<AddCourseForm />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
};

export default App;
