import { useState } from 'react';
import { getCourseStudents } from '../api';

const CourseStudents = () => {
    const [courseId, setCourseId] = useState('');
    const [students, setStudents] = useState([]);

    const handleSearch = async () => {
        try {
            const response = await getCourseStudents(courseId);
            setStudents(response.data);
        } catch (error) {
            console.error(error);
        }
    };

    return (
        <div className="max-w-lg mx-auto p-6 bg-white rounded-lg shadow-md">
            <h2 className="text-2xl font-semibold text-center mb-6">Search Course Students</h2>
            <div className="space-y-4">
                {/* Course ID Input */}
                <div>
                    <label htmlFor="courseId" className="block text-sm font-medium text-gray-700">
                        Course ID
                    </label>
                    <input
                        id="courseId"
                        type="number"
                        placeholder="Enter course ID"
                        value={courseId}
                        onChange={(e) => setCourseId(e.target.value)}
                        className="mt-1 w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                </div>

                {/* Search Button */}
                <button
                    onClick={handleSearch}
                    className="w-full py-2 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                >
                    Search
                </button>

                {/* Student List */}
                <div className="mt-6">
                    <h3 className="text-lg font-semibold text-gray-800">Students List</h3>
                    {students.length === 0 ? (
                        <p className="text-gray-500 mt-2">No students found for this course ID.</p>
                    ) : (
                        <ul className="space-y-2 mt-2">
                            {students.map((student) => (
                                <li
                                    key={student.id}
                                    className="p-4 border border-gray-200 rounded-md shadow-sm hover:bg-gray-50"
                                >
                                    <p className="font-medium text-gray-900">{student.name}</p>
                                    <p className="text-sm text-gray-600">{student.email}</p>
                                </li>
                            ))}
                        </ul>
                    )}
                </div>
            </div>
        </div>
    );
};

export default CourseStudents;
