import { useEffect, useState } from 'react';
import { getStudents, deleteStudent } from '../api';

const StudentList = () => {
    const [students, setStudents] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            const response = await getStudents();
            setStudents(response.data);
        };
        fetchData();
    }, []);

    const handleDelete = async (id) => {
        try {
            await deleteStudent(id);
            setStudents(students.filter((s) => s.id !== id));
        } catch (error) {
            console.error(error);
        }
    };

    return (
        <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-md">
            <h2 className="text-2xl font-semibold text-center mb-6">Student List</h2>
            <ul className="space-y-4">
                {students.map((student) => (
                    <li
                        key={student.id}
                        className="flex justify-between items-center p-4 border border-gray-200 rounded-md shadow-sm hover:bg-gray-50"
                    >
                        <div>
                            <p className="font-medium text-gray-900">{student.name}</p>
                            <p className="text-sm text-gray-600">{student.email}</p>
                            <p className="text-sm text-gray-500">Course ID: {student.courseId}</p>
                        </div>
                        <button
                            onClick={() => handleDelete(student.id)}
                            className="ml-4 px-4 py-2 bg-red-600 text-white font-semibold rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
                        >
                            Delete
                        </button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default StudentList;
