import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const AddCourseForm = () => {
    const [form, setForm] = useState({ name: '', code: '', duration: '' });
    const [message, setMessage] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage('');
        try {
            await axios.post('http://localhost:3000/courses', {
                name: form.name,
                code: form.code,
                duration: parseInt(form.duration),
            });
            setMessage('Course created successfully!');
            setForm({ name: '', code: '', duration: '' });
            setTimeout(() => navigate('/students'), 1500); // Redirect to student list after success
        } catch (error) {
            const errorMessage =
                error.response?.data?.error || 'An error occurred. Please try again.';
            setMessage(errorMessage);
        }
    };

    return (
        <div className="bg-gray-100 min-h-screen flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
                <h2 className="text-2xl font-bold text-center mb-4">Add a Course</h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium mb-1">Course Name:</label>
                        <input
                            type="text"
                            value={form.name}
                            onChange={(e) => setForm({ ...form, name: e.target.value })}
                            className="w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1">Course Code:</label>
                        <input
                            type="text"
                            value={form.code}
                            onChange={(e) => setForm({ ...form, code: e.target.value })}
                            className="w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1">Course Duration (in months):</label>
                        <input
                            type="number"
                            value={form.duration}
                            onChange={(e) => setForm({ ...form, duration: e.target.value })}
                            className="w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required
                        />
                    </div>
                    <button
                        type="submit"
                        className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700"
                    >
                        Add Course
                    </button>
                </form>
                {message && (
                    <p
                        className={`text-sm mt-4 ${message.includes('successfully')
                            ? 'text-green-600'
                            : 'text-red-600'
                            }`}
                    >
                        {message}
                    </p>
                )}
            </div>
        </div>
    );
};

export default AddCourseForm;
