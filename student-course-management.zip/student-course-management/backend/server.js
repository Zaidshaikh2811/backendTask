require('dotenv').config();
const cors = require('cors');
const express = require('express');
const bodyParser = require('body-parser');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();
const app = express();

app.use(bodyParser.json());
app.use(cors());
const PORT = process.env.PORT || 3000;



app.post('/students', async (req, res) => {
    const { name, email, courseId } = req.body;
    console.log(name, email, courseId);

    try {
        const course = await prisma.course.findUnique({
            where: { id: parseInt(courseId) },
        });

        if (!course) {
            return res.status(400).json({ error: "Course does not exist." });
        }
        const student = await prisma.student.create({ data: { name, email, courseId } });
        res.status(201).json(student);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});


app.get('/students', async (req, res) => {
    try {
        const students = await prisma.student.findMany({
            include: { course: true },
        });
        res.json(students);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
app.get('/courses/:id/students', async (req, res) => {
    const { id } = req.params;
    try {
        const students = await prisma.student.findMany({
            where: { courseId: parseInt(id) },
            include: { course: true },
        });
        res.json(students);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.put('/students/:id', async (req, res) => {
    const { id } = req.params;
    const { name, email, courseId } = req.body;
    try {
        const updatedStudent = await prisma.student.update({
            where: { id: parseInt(id) },
            data: { name, email, courseId },
        });
        res.json(updatedStudent);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
app.post('/courses', async (req, res) => {
    const { name, code, duration } = req.body;

    // Validation
    if (!name || !code || !duration) {
        return res.status(400).json({ error: "All fields are required: name, code, duration." });
    }

    try {
        const course = await prisma.course.create({
            data: {
                name,
                code,
                duration,
            },
        });
        res.status(201).json(course);
    } catch (error) {
        if (error.code === 'P2002') { // Unique constraint violation
            res.status(400).json({ error: "Course code must be unique." });
        } else {
            res.status(500).json({ error: error.message });
        }
    }
});

app.delete('/students/:id', async (req, res) => {
    const { id } = req.params;
    try {
        await prisma.student.delete({ where: { id: parseInt(id) } });
        res.status(204).send();
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});



app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
